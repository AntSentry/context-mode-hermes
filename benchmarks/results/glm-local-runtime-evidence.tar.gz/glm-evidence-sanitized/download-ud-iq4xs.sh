#!/usr/bin/env bash
# Ticket #4: fetch unsloth/GLM-5.3-Flash-GGUF @ a38483c8cd5df544f53d70fb281afe97369d5ab6
# UD-IQ4_XS (5 shards, 156822111200 B total) with per-shard SHA256 verification.
# Resumable: reruns continue partial files via curl -C -. Owned paths only.
set -u
REV=a38483c8cd5df544f53d70fb281afe97369d5ab6
REPO=unsloth/GLM-5.3-Flash-GGUF
DIR=/home/a1234/.local/share/hermes-glm/models/GLM-5.3-Flash-UD-IQ4_XS
BASE="https://huggingface.co/${REPO}/resolve/${REV}/UD-IQ4_XS"
LOG=/home/a1234/.cache/hermes-context-mode/ticket-4-evidence/download.log
mkdir -p "$DIR"

verify_and_fetch() {
  local f=$1 want_size=$2 want_sha=$3
  local path="$DIR/$f"
  for attempt in 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15; do
    local have=0
    [ -f "$path" ] && have=$(stat -c%s "$path")
    if [ "$have" -eq "$want_size" ]; then
      echo "$(date -Is) $f: size ok, hashing" >>"$LOG"
      local got
      got=$(sha256sum "$path" | cut -d' ' -f1)
      if [ "$got" = "$want_sha" ]; then
        echo "$(date -Is) $f: SHA256 VERIFIED $got" >>"$LOG"
        return 0
      fi
      echo "$(date -Is) $f: SHA256 MISMATCH got=$got want=$want_sha; refetching from byte 0" >>"$LOG"
      rm -f "$path"
    elif [ "$have" -gt "$want_size" ]; then
      echo "$(date -Is) $f: oversized ($have > $want_size); refetching" >>"$LOG"
      rm -f "$path"
    fi
    echo "$(date -Is) $f: attempt $attempt, have=${have}B of ${want_size}B, resuming" >>"$LOG"
    curl -fL --connect-timeout 30 --speed-time 120 --speed-limit 10240 \
      -C - -o "$path" "$BASE/$f" >>"$LOG" 2>&1
    local rc=$?
    echo "$(date -Is) $f: curl exit $rc" >>"$LOG"
  done
  echo "$(date -Is) $f: GAVE UP after 15 attempts" >>"$LOG"
  return 1
}

ok=0
verify_and_fetch 'GLM-5.3-Flash-UD-IQ4_XS-00001-of-00005.gguf' 9429984    'c2f3b6ab98d3df844f322ea376059202d2eaeedcee1f0eff455345b86a137dbd' && ok=$((ok+1))
verify_and_fetch 'GLM-5.3-Flash-UD-IQ4_XS-00002-of-00005.gguf' 49989334176 '7d64cf0395672c4322012841abec502ea7e20518299bb5e3069003f06f9e6de9' && ok=$((ok+1))
verify_and_fetch 'GLM-5.3-Flash-UD-IQ4_XS-00003-of-00005.gguf' 49607025280 '7c2c63c9c30f8060428fdf2ac935dbf2ee9ad8f771d62b6ae47a7f7f2c1520e7' && ok=$((ok+1))
verify_and_fetch 'GLM-5.3-Flash-UD-IQ4_XS-00004-of-00005.gguf' 49486530144 '06c90f191871317c92dd9d25a353b687aed44c50f3ac6c713e9fe410bc2d26dd' && ok=$((ok+1))
verify_and_fetch 'GLM-5.3-Flash-UD-IQ4_XS-00005-of-00005.gguf' 7729791616  '66ebf9ec85e04d3f44af674ae4f694acbc89cc53db75e42f2f4d3646bf321c0d' && ok=$((ok+1))

total=$(cat "$DIR"/*.gguf 2>/dev/null | wc -c)
echo "$(date -Is) shards_ok=$ok total_bytes_on_disk=$total" >>"$LOG"
if [ "$ok" -eq 5 ] && [ "$total" -eq 156822111200 ]; then
  echo "$(date -Is) ALL_SHARDS_VERIFIED" >>"$LOG"
  touch "$DIR/.verified"
  exit 0
fi
exit 1
