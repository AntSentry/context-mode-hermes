#!/usr/bin/env python3
"""Bisect3: identical profile setup; only the chat cwd differs."""
import json, shutil, subprocess, sys, os
from pathlib import Path
REPO = Path("/home/a1234/.cache/hermes-context-mode/worktrees/ticket-2")
sys.path.insert(0, str(REPO))
from context_mode_hermes import verify as V
VENV_PY = Path("/home/a1234/.cache/hermes-context-mode/hermes-agent/.venv/bin/python")
HERMES = VENV_PY.parent / "hermes"
CLI = VENV_PY.parent / "context-mode-hermes"
ENGINE = Path("/home/a1234/.local/share/hermes-context-mode-validation/home/context-mode-runtime/node_modules/.bin/context-mode")
ROOT = Path("/home/a1234/.cache/hermes-context-mode/evidence/ticket-2/bisect3")
if ROOT.exists(): shutil.rmtree(ROOT)
ROOT.mkdir(parents=True)
interrupt = V._InterruptFlag()
provider = V.LoopbackProvider(ROOT / "provider", "key-bisect3")
provider.start()

def build(name):
    home = ROOT / name
    home.mkdir(parents=True); os.chmod(home, 0o700)
    V.write_owned_config(home, provider, ENGINE, "key-bisect3")
    cfg = json.loads((home / "config.yaml").read_text())
    cfg["theme"] = "dark"; cfg["operator_note"] = "ticket-2 owned profile marker"
    cfg["history"] = {"max_entries": 4096}
    cfg.setdefault("plugins", {}).setdefault("entries", {})["example-plugin"] = {
        "description": "unrelated operator plugin metadata (not enabled)"}
    (home / "config.yaml").write_text(json.dumps(cfg, indent=2))
    r = subprocess.run([str(CLI), "--home", str(home), "--engine-bin", str(ENGINE)],
                       env=V.child_environment(home), capture_output=True, text=True)
    assert r.returncode == 0, r.stderr[-400:]
    return home

def probe(label, home, cwd, timeout=100.0):
    env = V.child_environment(home); env["TERM"] = "xterm-256color"
    driver = V.PtyChatDriver([str(HERMES), "--cli"], env, cwd, ROOT / f"{label}.log")
    ok, elapsed = driver.wait_for("❯", timeout, interrupt)
    print(f"{label}: ready={ok} elapsed={elapsed:.1f}s", flush=True)
    if ok:
        driver.send("/exit")
        try: driver.proc.wait(timeout=20)
        except Exception: V.stop_child(driver.proc, V.ProcessLedger(), 20)
    else:
        V.stop_child(driver.proc, V.ProcessLedger(), 20)
    driver.close()
    return ok

try:
    h1 = build("inside")
    ws_in = h1 / "workspace"; ws_in.mkdir()
    probe("cwd-inside-home", h1, ws_in)
    h2 = build("outside")
    ws_out = ROOT / "workspace-out"; ws_out.mkdir()
    probe("cwd-outside-home", h2, ws_out)
finally:
    provider.stop()
print("DONE")
