#!/usr/bin/env python3
"""Ticket-2 acceptance: reversible, profile-scoped context-mode removal.

Operator-run, evidence-producing lifecycle proof on explicit owned profiles:

  A  primary lifecycle profile:  seed -> public CLI install -> native later
     edits -> live /ctx session -> public CLI --remove -> native session with
     NO context-mode (commands, hooks, MCP) -> backup byte-exact recovery ->
     repeated remove + no-op -> OFFLINE re-enable (no Node/npm on PATH) ->
     re-enabled /ctx session against retained index -> independent public MCP
     retrieval of the pre-indexed sentence.
  B  another profile with its own registration: byte-identical across A's
     removal and re-enable (profile scoping).
  C  removed with an empty PATH (no Node/npm reachable): removal needs none.
  D  registered against a throwaway engine runtime copy, then the engine copy
     is deleted: --remove still succeeds (configuration-only).

Guarantees enforced throughout (helpers reused from context_mode_hermes.verify):
  - only explicitly owned fresh profiles are touched; the default profile is
    fingerprinted before/after and must stay identical;
  - a loopback provider on 127.0.0.1 rejects every /v1/chat/completions call;
    any inference attempt aborts the run (zero model inference);
  - every interactive Hermes process has its /proc identity (HERMES_HOME)
    verified BEFORE any keystroke; cleanup signals only identity-verified
    owned PIDs (per-PID HERMES_HOME + start time), never process groups;
  - raw console output, pty transcripts, config snapshots and digests are
    retained under the evidence directory.

Exit 0 only if every check passed. Final stdout line:
  CM-TICKET2: <STATUS> evidence=<dir>
"""
from __future__ import annotations

import argparse
import asyncio
import hashlib
import json
import os
import shutil
import signal
import subprocess
import sys
import time
import uuid
from pathlib import Path

REPO = Path("/home/a1234/.cache/hermes-context-mode/worktrees/ticket-2")
sys.path.insert(0, str(REPO))

from context_mode_hermes import verify as V  # noqa: E402
from context_mode_hermes.engine import Engine  # noqa: E402
from context_mode_hermes.install import ENGINE_VERSION  # noqa: E402

VENV_PY = Path("/home/a1234/.cache/hermes-context-mode/hermes-agent/.venv/bin/python")
HERMES = Path("/home/a1234/.cache/hermes-context-mode/hermes-agent/.venv/bin/hermes")
PUBLIC_CLI = Path("/home/a1234/.cache/hermes-context-mode/hermes-agent/.venv/bin/context-mode-hermes")
ENGINE_BIN = Path(
    "/home/a1234/.local/share/hermes-context-mode-validation/home/"
    "context-mode-runtime/node_modules/.bin/context-mode"
)
ENGINE_RUNTIME = ENGINE_BIN.parent.parent.parent  # .../context-mode-runtime
EVIDENCE_ROOT = Path("/home/a1234/.cache/hermes-context-mode/evidence/ticket-2")

REPORT_SCHEMA = "context-mode-hermes/ticket2-removal-acceptance/1"
CTX = "context-mode"


class Acceptance:
    def __init__(self, args: argparse.Namespace) -> None:
        self.args = args
        stamp = time.strftime("%Y%m%d-%H%M%S")
        self.evid = args.evidence_dir or (EVIDENCE_ROOT / f"run-{stamp}-{uuid.uuid4().hex[:6]}")
        self.evid.mkdir(parents=True, exist_ok=False)
        self.artifacts = self.evid / "artifacts"
        self.artifacts.mkdir()
        self.interrupt = V._InterruptFlag()
        self.ledger = V.ProcessLedger()
        self.checks: dict[str, dict] = {}
        self.journal_lines: list[str] = []
        self.provider: V.LoopbackProvider | None = None
        self.api_key = f"cm-ticket2-{uuid.uuid4().hex}"
        self.nonce = f"CM-TICKET2-NONCE-{uuid.uuid4().hex[:10]}"
        self.sentence = f"{self.nonce} the amber lighthouse catalogs quiet harbors before dawn"
        self.sentence_body = self.sentence.replace(f"{self.nonce} ", "", 1)
        self.profiles: dict[str, Path] = {}
        self.workspace = self.evid / "workspace"
        self.empty_bin = self.evid / "empty-bin"
        self.default_root = Path(os.environ.get("HERMES_HOME", str(Path.home() / ".hermes")))
        self.default_before: dict | None = None
        self.default_after: dict | None = None
        self.status = "pass"
        self.error: str | None = None
        self._interrupted: int | None = None

    # ── plumbing ────────────────────────────────────────────────────────────
    def journal(self, message: str) -> None:
        line = f"{time.strftime('%H:%M:%S')} {message}"
        self.journal_lines.append(line)
        print(line, flush=True)

    def check(self, name: str, ok: bool, detail: str) -> bool:
        ok = bool(ok)
        self.checks[name] = {"ok": ok, "detail": detail}
        self.journal(("PASS " if ok else "FAIL ") + name + " — " + detail[:240])
        return ok

    @staticmethod
    def digest(path: Path) -> str:
        return hashlib.sha256(path.read_bytes()).hexdigest()

    def snapshot_tree(self, root: Path) -> dict[str, dict]:
        out: dict[str, dict] = {}
        if not root.exists():
            return {"<absent>": {}}
        for item in sorted(root.rglob("*")):
            rel = str(item.relative_to(root))
            if item.is_dir():
                out[rel + "/"] = {"type": "dir"}
            elif item.is_file():
                size = item.stat().st_size
                entry = {"type": "file", "size": size}
                if size <= 8 * 1024 * 1024:
                    entry["sha256"] = self.digest(item)
                out[rel] = entry
        return out

    def console(self, label: str, argv: list[str], env: dict[str, str],
                cwd: Path | None = None, timeout: float = 300.0) -> dict:
        """Run a public console command, retain its full output as evidence."""
        self.journal(f"console[{label}] $ {' '.join(str(a) for a in argv)}")
        started = time.monotonic()
        proc = subprocess.run(
            [str(a) for a in argv], env=env, cwd=str(cwd or self.evid),
            capture_output=True, text=True, timeout=timeout)
        record = {
            "argv": [str(a) for a in argv],
            "path": env.get("PATH"),
            "returncode": proc.returncode,
            "stdout": proc.stdout,
            "stderr": proc.stderr,
            "elapsed_s": round(time.monotonic() - started, 2),
        }
        (self.artifacts / f"{label}.json").write_text(
            json.dumps(record, indent=2), encoding="utf-8")
        self.journal(f"console[{label}] rc={proc.returncode} in {record['elapsed_s']}s")
        return record

    def public_cli(self, label: str, home: Path, *extra: str,
                   path: str | None = None) -> tuple[dict, dict]:
        env = V.child_environment(home)
        env["PATH"] = path if path is not None else env.get("PATH", "")
        record = self.console(label, [PUBLIC_CLI, "--home", str(home), *extra], env)
        report: dict = {}
        lines = record["stdout"].splitlines()
        for index, line in enumerate(lines):
            if line.strip() == "{":
                for end in range(index, len(lines)):
                    if lines[end].strip() == "}":
                        try:
                            report = json.loads("\n".join(lines[index:end + 1]))
                        except json.JSONDecodeError:
                            report = {}
                        break
                if report:
                    break
        return record, report

    def load_config(self, home: Path) -> dict:
        """Parse a profile config with Hermes' own reader (handles the YAML
        the native writer emits as well as the JSON the seed uses)."""
        env = V.child_environment(home)
        proc = subprocess.run(
            [str(VENV_PY), "-c",
             "import json; from hermes_cli.config import read_raw_config; "
             "print(json.dumps(read_raw_config()))"],
            env=env, capture_output=True, text=True, timeout=60)
        if proc.returncode != 0:
            raise RuntimeError(f"hermes config read failed for {home}: {proc.stderr[-400:]}")
        return json.loads(proc.stdout)
    def ctx_registration(self, cfg: dict) -> dict:
        plugins = cfg.get("plugins", {}) if isinstance(cfg.get("plugins"), dict) else {}
        servers = cfg.get("mcp_servers", {}) if isinstance(cfg.get("mcp_servers"), dict) else {}
        enabled = plugins.get("enabled", [])
        disabled = plugins.get("disabled", [])
        entries = plugins.get("entries", {})
        return {
            "enabled": CTX in enabled, "disabled": CTX in disabled,
            "plugin_entry": CTX in entries, "mcp_server": CTX in servers,
        }

    def without_ctx(self, cfg: dict) -> dict:
        """Config with every context-mode registration site removed (for
        comparing operator-owned content across install/remove/re-enable)."""
        import copy
        trimmed = copy.deepcopy(cfg)
        plugins = trimmed.get("plugins")
        if isinstance(plugins, dict):
            entries = plugins.get("entries")
            if isinstance(entries, dict):
                entries.pop(CTX, None)
            for key in ("enabled", "disabled"):
                seq = plugins.get(key)
                if isinstance(seq, list):
                    plugins[key] = [n for n in seq if n != CTX]
            if not plugins:
                trimmed.pop("plugins")
        servers = trimmed.get("mcp_servers")
        if isinstance(servers, dict):
            servers.pop(CTX, None)
            if not servers:
                trimmed.pop("mcp_servers")
        return trimmed

    def seed_operator_extras(self, home: Path) -> None:
        """Layer operator-owned, context-mode-unrelated settings on top of the
        loopback-seeded config: these must survive remove and re-enable."""
        cfg = self.load_config(home)
        cfg["theme"] = "dark"
        cfg["operator_note"] = "ticket-2 owned profile marker"
        cfg["history"] = {"max_entries": 4096}
        cfg.setdefault("plugins", {}).setdefault("entries", {})["example-plugin"] = {
            "description": "unrelated operator plugin metadata (not enabled)",
        }
        (home / "config.yaml").write_text(
            json.dumps(cfg, indent=2), encoding="utf-8")

    # ── phases ──────────────────────────────────────────────────────────────
    def preflight(self) -> None:
        self.default_before = V.fingerprint_default_profile(self.default_root)
        (self.artifacts / "default-profile-before.json").write_text(
            json.dumps(self.default_before, indent=2), encoding="utf-8")
        for name in ("A", "B", "C", "D"):
            home = self.evid / "homes" / name
            home.mkdir(parents=True)
            os.chmod(home, 0o700)
            (home / ".ticket2-owned").write_text(json.dumps({
                "owner": "context-mode-hermes ticket-2 acceptance",
                "uuid": uuid.uuid4().hex,
                "created": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            }, indent=2), encoding="utf-8")
            self.profiles[name] = home
        self.workspace.mkdir(parents=True)
        self.empty_bin.mkdir(parents=True)
        os.chmod(self.empty_bin, 0o755)

        hermes_out, _ = V.run_bounded(
            [str(HERMES), "--version"], cwd=self.evid,
            env=V.child_environment(self.profiles["A"]),
            timeout=120, interrupt=self.interrupt, ledger=self.ledger)
        version_line = hermes_out.splitlines()[0] if hermes_out else ""
        self.check("hermes_pin", "0.22.5" in version_line,
                   f"pinned Hermes CLI: {version_line!r}")

        engine = Engine(binary=str(ENGINE_BIN), storage_root=str(self.profiles["A"] / CTX))
        self.check("engine_pin", engine.available and engine.version == ENGINE_VERSION,
                   f"engine {ENGINE_BIN} version={engine.version} want={ENGINE_VERSION}")

        identity = subprocess.run(
            [str(VENV_PY), "-c",
             "import context_mode_hermes, hermes_cli, sys; "
             "print(context_mode_hermes.__file__); print(hermes_cli.__file__)"],
            env=V.child_environment(self.profiles["A"]), capture_output=True, text=True)
        module = identity.stdout.splitlines()[0] if identity.stdout else ""
        self.check("adapter_under_test", identity.returncode == 0 and module.startswith(str(REPO)),
                   f"public CLI imports adapter from {module!r} (worktree {REPO})")

        help_rc = subprocess.run([str(PUBLIC_CLI), "--help"], capture_output=True)
        self.check("public_cli_entrypoint", help_rc.returncode == 0,
                   f"context-mode-hermes console script rc={help_rc.returncode}")

        self.provider = V.LoopbackProvider(self.evid / "provider", self.api_key)
        self.provider.start()
        self.journal(f"loopback provider at {self.provider.base_url} (rejects inference)")
        pre_existing = V.owned_hermes_pids(EVIDENCE_ROOT, exclude={os.getpid()})
        if pre_existing:
            raise V.Refused(
                f"{len(pre_existing)} process(es) already carry HERMES_HOME under "
                f"{EVIDENCE_ROOT}; refusing to start until they are cleaned: "
                f"{[h.get('pid') for h in pre_existing]}")

        for name, home in self.profiles.items():
            resolved = home.resolve()
            if str(resolved).startswith(str(self.default_root)):
                raise V.Refused(f"profile {name} would live inside the default profile; refusing")

    def phase_seed_primary(self) -> None:
        A = self.profiles["A"]
        V.write_owned_config(A, self.provider, ENGINE_BIN, self.api_key)
        self.seed_operator_extras(A)
        (self.artifacts / "A-config0-seed.json").write_bytes((A / "config.yaml").read_bytes())
        cfg = self.load_config(A)
        self.check("seed_operators_own_config",
                   cfg.get("theme") == "dark" and cfg.get("operator_note")
                   and "example-plugin" in cfg.get("plugins", {}).get("entries", {}),
                   "operator-owned settings present before install; "
                   f"registration sites pre-seeded: {self.ctx_registration(cfg)}")

    def phase_install_primary(self) -> None:
        record, report = self.public_cli("A-install", self.profiles["A"],
                                         "--engine-bin", str(ENGINE_BIN))
        cfg = self.load_config(self.profiles["A"])
        reg = self.ctx_registration(cfg)
        server = cfg.get("mcp_servers", {}).get(CTX, {})
        merged_ok = (
            reg["enabled"] and reg["plugin_entry"] and reg["mcp_server"]
            and server.get("command") == str(VENV_PY)
            and any(str(ENGINE_BIN) in str(a) for a in server.get("args", []))
            and server.get("env", {}).get("HERMES_HOME") == str(self.profiles["A"])
        )
        self.check("install_public_cli", record["returncode"] == 0 and merged_ok,
                   f"public CLI install rc={record['returncode']}; registration={reg}; "
                   f"engine_binary={cfg['plugins']['entries'][CTX]['settings'].get('engine_binary')!r}")
        self.check("install_preserves_operator_config",
                   cfg.get("theme") == "dark" and cfg.get("operator_note") == "ticket-2 owned profile marker"
                   and "example-plugin" in cfg.get("plugins", {}).get("entries", {})
                   and cfg.get("history") == {"max_entries": 4096},
                   "unrelated operator settings survived the merge untouched")
        backup = self.profiles["A"] / "config.yaml.before-context-mode"
        self.check("install_pre_backup_byte_exact",
                   backup.exists() and self.digest(backup) == self.digest(self.artifacts / "A-config0-seed.json"),
                   f"pre-install snapshot {backup.name} byte-exact "
                   f"(sha256={self.digest(backup)[:16]}…)")
        self.storage_before = self.snapshot_tree(self.profiles["A"] / CTX)

    def phase_native_later_edits(self) -> None:
        """Operator keeps editing the profile through Hermes' own config writer
        after the integration was installed (e.g. `hermes config set`)."""
        A = self.profiles["A"]
        script = (
            "import json; from hermes_cli.config import load_config, save_config; "
            "cfg = load_config(); cfg['theme'] = 'light'; "
            "cfg['operator_note'] = 'ticket-2 later native edit'; "
            "save_config(cfg, strip_defaults=False); "
            "print(json.dumps({'theme': cfg.get('theme')}))"
        )
        env = V.child_environment(A)
        record = self.console("A-native-later-edit", [VENV_PY, "-c", script], env)
        cfg = self.load_config(A)
        self.check("later_native_edits", record["returncode"] == 0
                   and cfg.get("theme") == "light"
                   and cfg.get("operator_note") == "ticket-2 later native edit"
                   and self.ctx_registration(cfg)["mcp_server"],
                   "hermes_cli-native edit landed while context-mode stayed registered")
        (self.artifacts / "A-config1-later-edits.json").write_bytes((A / "config.yaml").read_bytes())
        (self.artifacts / "A-config1-parsed.json").write_text(
            json.dumps(cfg, indent=2), encoding="utf-8")

    def phase_another_profile(self) -> None:
        B = self.profiles["B"]
        V.write_owned_config(B, self.provider, ENGINE_BIN, self.api_key + "-b")
        record, report = self.public_cli("B-install", B, "--engine-bin", str(ENGINE_BIN))
        self.check("another_profile_registered",
                   record["returncode"] == 0 and self.ctx_registration(self.load_config(B))["mcp_server"],
                   f"profile B carries an independent registration (rc={record['returncode']})")
        (self.artifacts / "B-config1.json").write_bytes((B / "config.yaml").read_bytes())

    def _open_session(self, name: str, home: Path, log: str) -> V.PtyChatDriver:
        env = V.child_environment(home)
        env["TERM"] = "xterm-256color"
        driver = V.PtyChatDriver([str(HERMES), "--cli"], env, self.workspace,
                                 self.evid / "transcript" / log)
        live = V._proc_environ(driver.proc.pid)
        for _ in range(30):  # fork->exec race: environ may be briefly unreadable
            if live and live.get("HERMES_HOME"):
                break
            time.sleep(0.1)
            live = V._proc_environ(driver.proc.pid)
        self.ledger.note_proof(driver.proc.pid, live, V._proc_cmdline(driver.proc.pid))
        isolated = bool(live) and live.get("HERMES_HOME") == str(home)
        self.check(f"{name}_identity_verified", isolated,
                   f"pid {driver.proc.pid} /proc HERMES_HOME="
                   f"{(live or {}).get('HERMES_HOME')!r} == {str(home)!r} before first keystroke")
        if not isolated:
            raise V.Refused("refusing to type into an unverified process")
        ready, elapsed = driver.wait_for(
            "❯", self.args.command_timeout, self.interrupt,
            abort=lambda: (self.provider.inference_attempts if self.provider else 0) > 0)
        self.check(f"{name}_native_prompt_ready", ready,
                   f"native ❯ prompt {'ready' if ready else 'ABSENT'} after {elapsed:.1f}s; "
                   "no keystrokes sent before readiness")
        if not ready:
            raise V.Refused(f"{name}: native prompt unavailable")
        return driver

    def _close_session(self, name: str, driver: V.PtyChatDriver) -> None:
        driver.send("/exit")
        try:
            rc = driver.proc.wait(timeout=self.args.exit_timeout)
            self.check(f"{name}_clean_exit", True, f"/exit -> process rc={rc}")
        except subprocess.TimeoutExpired:
            self.check(f"{name}_clean_exit", False,
                       f"no exit within {self.args.exit_timeout}s of /exit; stopping per-PID")
            V.stop_child(driver.proc, self.ledger, self.args.exit_timeout)
        finally:
            driver.close()

    def _dispatch(self, driver: V.PtyChatDriver, name: str, command: str,
                  marker: str) -> tuple[bool, str]:
        """Send a slash command and wait for a CONTENT marker (never the ❯
        prompt glyph: it is always present in the status line)."""
        if self.provider and self.provider.inference_attempts:
            raise V.Refused(f"inference attempted during {command!r}; aborting")
        position = driver.mark()
        driver.send(command)
        ok, elapsed = driver.wait_for(
            marker, self.args.command_timeout, self.interrupt, since=position,
            abort=lambda: (self.provider.inference_attempts if self.provider else 0) > 0)
        return ok, V.normalize_terminal_output(driver._view(position))

    def _live_ctx_processes(self, home: Path) -> list[dict]:
        """Owned processes currently carrying context-mode machinery."""
        needles = ("context_mode_hermes", "node_modules/.bin/context-mode")
        return [h for h in V.owned_hermes_pids(home, exclude={os.getpid()})
                if any(n in (h.get("cmdline") or "") for n in needles)]

    def phase_session_installed(self) -> None:
        driver = self._open_session("session1_installed", self.profiles["A"], "session1-installed.log")
        try:
            plan = [
                ("stats", "/ctx-stats", "v1.0.169"),
                ("doctor", "/ctx-doctor", "mcp_servers['context-mode'] configured"),
                ("index", f'/ctx-index --text "{self.sentence}" --source cm-ticket2-acceptance',
                 "from: cm-ticket2-acceptance"),
                ("search", "/ctx-search amber lighthouse", self.nonce),
            ]
            for name, command, marker in plan:
                ok, view = self._dispatch(driver, name, command, marker)
                self.check(f"session1_{name}", ok, f"{command!r} -> {marker!r} "
                           f"{'matched' if ok else 'NOT matched'}; tail: {view[-160:]!r}")
        finally:
            self._close_session("session1_installed", driver)
        self.stop_gateway(self.profiles["A"], "after_session1_before_remove")
        self.storage_indexed = self.snapshot_tree(self.profiles["A"] / CTX)

    def phase_remove_primary(self) -> None:
        pre_remove = self.profiles["A"] / "config.yaml"
        (self.artifacts / "A-config2-pre-remove.json").write_bytes(pre_remove.read_bytes())
        record, report = self.public_cli("A-remove-1", self.profiles["A"], "--remove")
        cfg = self.load_config(self.profiles["A"])
        reg = self.ctx_registration(cfg)
        guidance_ok = ("Restart this profile's Hermes gateway" in record["stdout"]
                       and "Configuration-only removal" in record["stdout"])
        self.check("remove_public_cli", record["returncode"] == 0 and report.get("changed") is True
                   and not any(reg.values()),
                   f"public CLI --remove rc={record['returncode']} changed={report.get('changed')} "
                   f"registration sites now={reg}")
        self.check("remove_console_guidance", guidance_ok,
                   "console explains gateway restart, retention and offline re-enable")
        seed = json.loads((self.artifacts / "A-config0-seed.json").read_text())
        later = json.loads((self.artifacts / "A-config1-parsed.json").read_text())
        self.check("remove_preserves_operator_config",
                   self.without_ctx(cfg) == self.without_ctx(later),
                   "every operator-owned key (later native edits included) is intact; "
                   "only context-mode sites were removed")
        recovery = Path(str(report.get("recovery_backup")))
        self.recovery_backup = recovery
        self.check("recovery_backup_byte_exact",
                   recovery.is_file() and recovery.read_bytes()
                   == (self.artifacts / "A-config2-pre-remove.json").read_bytes(),
                   f"recovery copy {recovery.name} is byte-exact the just-removed config "
                   f"(sha256={self.digest(recovery)[:16]}…)")
        backup = self.profiles["A"] / "config.yaml.before-context-mode"
        self.check("pre_install_backup_retained",
                   backup.exists() and self.digest(backup) == self.digest(self.artifacts / "A-config0-seed.json"),
                   "pre-install snapshot still byte-exact after removal")
        retained = report.get("retained", {})
        engine_still = ENGINE_BIN.is_file() and Engine(
            binary=str(ENGINE_BIN), storage_root=self.profiles["A"] / CTX).version == ENGINE_VERSION
        self.check("shared_engine_not_uninstalled", engine_still,
                   f"engine binary still present, version={ENGINE_VERSION}; "
                   f"report retained={retained}")
        self.storage_removed = self.snapshot_tree(self.profiles["A"] / CTX)
        self.check("indexed_data_retained_on_disk",
                   self.storage_indexed == self.storage_removed and bool(self.storage_removed),
                   f"indexed storage under {self.profiles['A'] / CTX} unchanged by removal "
                   f"({len(self.storage_removed)} entries)")
        self.check("host_state_retained",
                   (self.profiles["A"] / "context-mode-host").exists()
                   and (self.profiles["A"] / "context-mode-host" / "session-roots").exists(),
                   "captured session roots survive removal")
        b_now = self.digest(self.profiles["B"] / "config.yaml")
        b_before = self.digest(self.artifacts / "B-config1.json")
        self.check("other_profile_untouched", b_now == b_before,
                   f"profile B config byte-identical across A's removal ({b_now[:16]}…)")
        mid_default = V.fingerprint_default_profile(self.default_root)
        self.check("default_profile_unchanged_mid", mid_default == self.default_before,
                   f"default profile {self.default_root} fingerprint stable")

    def phase_session_removed(self) -> None:
        """New native Hermes process on the removed profile: normal CLI works,
        context-mode commands/hooks/MCP are gone."""
        driver = self._open_session("session2_removed", self.profiles["A"], "session2-removed.log")
        try:
            ctx_live = self._live_ctx_processes(self.profiles["A"])
            self.check("session2_no_ctx_processes", not ctx_live,
                       "no context-mode MCP proxy/engine child runs under the removed "
                       f"profile while native Hermes is active; found: {ctx_live}")
            ok, view = self._dispatch(driver, "ctx_dispatch_rejected",
                                      "/ctx-stats", "Unknown command")
            self.check("session2_ctx_dispatch_rejected", ok,
                       f"/ctx-stats on the removed profile is rejected as unknown "
                       f"(native Hermes CLI still serves commands); tail: {view[-200:]!r}")
        finally:
            self._close_session("session2_removed", driver)
        self.stop_gateway(self.profiles["A"], "after_session2_before_recovery")

    def phase_recovery_and_repeat(self) -> None:
        A = self.profiles["A"]
        recovery_src = getattr(self, "recovery_backup", None)
        if recovery_src is None or not Path(recovery_src).is_file():
            candidates = sorted(A.rglob("*context-mode-removal*"))
            recovery_src = max(candidates, key=lambda p: p.stat().st_mtime) if candidates else None
        self.check("recovery_copy_located", recovery_src is not None,
                   f"Hermes config-backup for removal present: {recovery_src}")
        if recovery_src is None:
            return
        removed_digest = self.digest(self.artifacts / "A-config2-pre-remove.json")
        self.check("recovery_copy_matches_removed_state",
                   self.digest(recovery_src) == removed_digest,
                   "newest recovery copy is the byte-exact removed configuration")
        shutil.copy2(recovery_src, A / "config.yaml")
        restored = self.load_config(A)
        reg = self.ctx_registration(restored)
        self.check("recovery_restores_registration",
                   reg["mcp_server"] and reg["plugin_entry"] and reg["enabled"],
                   f"restoring the recovery copy alone re-registers context-mode: {reg}")
        self.check("recovery_preserves_operator_state",
                   self.without_ctx(restored) == self.without_ctx(
                       json.loads((self.artifacts / "A-config1-parsed.json").read_text())),
                   "recovered config still carries every operator-owned key")

        record, report = self.public_cli("A-remove-2", A, "--remove")
        self.check("remove_after_recovery", record["returncode"] == 0 and report.get("changed") is True,
                   f"second removal after manual recovery changed={report.get('changed')}")
        before_noop = (A / "config.yaml").read_bytes()
        record, report = self.public_cli("A-remove-3-noop", A, "--remove")
        after_noop = (A / "config.yaml").read_bytes()
        self.check("repeated_remove_noop",
                   record["returncode"] == 0 and report.get("changed") is False
                   and before_noop == after_noop,
                   f"third --remove is a successful no-op (changed={report.get('changed')}, "
                   "config bytes untouched)")

    def phase_offline_and_missing(self) -> None:
        C = self.profiles["C"]
        V.write_owned_config(C, self.provider, ENGINE_BIN, self.api_key + "-c")
        rec_install, _ = self.public_cli("C-install", C, "--engine-bin", str(ENGINE_BIN))
        self.check("profile_c_installed", rec_install["returncode"] == 0, "profile C registered")
        record, report = self.public_cli(
            "C-remove-offline", C, "--remove", path=str(self.empty_bin))
        reg = self.ctx_registration(self.load_config(C))
        node_gone = not shutil.which("node", path=str(self.empty_bin))
        self.check("remove_without_node_npm",
                   record["returncode"] == 0 and not any(reg.values()) and node_gone,
                   f"--remove succeeded with PATH={self.empty_bin!s} (no node/npm resolvable); "
                   f"sites={reg}")

        D = self.profiles["D"]
        throwaway = self.evid / "throwaway-engine" / "context-mode-runtime"
        self.journal("copying engine runtime for the missing-engine profile…")
        shutil.copytree(ENGINE_RUNTIME, throwaway, symlinks=True)
        d_bin = throwaway / "node_modules" / ".bin" / "context-mode"
        rec_install, _ = self.public_cli("D-install", D, "--engine-bin", str(d_bin))
        self.check("profile_d_installed", rec_install["returncode"] == 0,
                   f"profile D registered against throwaway engine ({d_bin})")
        shutil.rmtree(throwaway)
        self.journal("throwaway engine runtime deleted before removal")
        record, report = self.public_cli("D-remove-engine-missing", D, "--remove")
        reg = self.ctx_registration(self.load_config(D))
        retained_engine = (report.get("retained") or {}).get("engine_binary")
        self.check("remove_with_engine_missing",
                   record["returncode"] == 0 and not any(reg.values()),
                   f"--remove succeeded although the configured engine binary no longer exists; "
                   f"report retained.engine_binary={retained_engine!r}")

    def phase_reenable_offline(self) -> None:
        A = self.profiles["A"]
        record, report = self.public_cli(
            "A-reenable-offline", A, "--engine-bin", str(ENGINE_BIN),
            path=str(self.empty_bin))
        cfg = self.load_config(A)
        reg = self.ctx_registration(cfg)
        npm_free = not shutil.which("npm", path=str(self.empty_bin))
        later = json.loads((self.artifacts / "A-config1-parsed.json").read_text())
        self.check("reenable_offline_public_cli",
                   record["returncode"] == 0 and reg["mcp_server"] and reg["enabled"] and npm_free,
                   f"re-enable rc={record['returncode']} with PATH={self.empty_bin!s} "
                   f"(no npm/node reachable); sites={reg}")
        self.check("reenable_preserves_operator_config",
                   self.without_ctx(cfg) == self.without_ctx(later),
                   "operator-owned settings (incl. later native edits) still intact after "
                   "remove + offline re-enable")
        server = cfg.get("mcp_servers", {}).get(CTX, {})
        self.check("reenable_uses_retained_engine",
                   server.get("command") == str(VENV_PY)
                   and any(str(ENGINE_BIN) in str(a) for a in server.get("args", [])),
                   "re-enabled registration reuses the retained 1.0.169 engine; "
                   "no npm/network involved")

    def phase_session_reenabled(self) -> None:
        driver = self._open_session("session3_reenabled", self.profiles["A"], "session3-reenabled.log")
        try:
            ok, view = self._dispatch(driver, "stats", "/ctx-stats", "v1.0.169")
            self.check("session3_ctx_live_again", ok,
                       f"/ctx-stats after offline re-enable reports v1.0.169; tail: {view[-120:]!r}")
            ok, view = self._dispatch(driver, "retained_search",
                                      "/ctx-search lighthouse catalogs", "harbors before dawn")
            self.check("session3_retained_content",
                       ok and self.sentence_body in view,
                       f"interactive search over the REMOVED-era index still returns the "
                       f"pre-indexed sentence; tail: {view[-200:]!r}")
        finally:
            self._close_session("session3_reenabled", driver)
        self.stop_gateway(self.profiles["A"], "after_session3")

    def phase_mcp_probe(self) -> None:
        from mcp import ClientSession, StdioServerParameters
        from mcp.client.stdio import stdio_client

        probe = "harbors before dawn"  # never typed as any interactive query

        async def round_trip() -> str:
            env = {k: v for k, v in os.environ.items() if k not in V.SCRUB_KEYS}
            env.update({
                "HERMES_HOME": str(self.profiles["A"]),
                "HOME": str(self.profiles["A"]),
                "CONTEXT_MODE_DIR": str(self.profiles["A"] / CTX),
                "CLAUDE_CONFIG_DIR": str(self.profiles["A"] / "context-mode-host"),
                "XDG_CONFIG_HOME": str(self.profiles["A"] / "context-mode-host" / "xdg-config"),
                "CLAUDE_PROJECT_DIR": str(self.workspace),
                "CONTEXT_MODE_PROJECT_DIR": str(self.workspace),
                "CLAUDE_SESSION_ID": "cm-ticket2-mcp-probe",
                "PYTHONPATH": str(REPO),
                "PATH": os.environ.get("PATH", ""),
            })
            parameters = StdioServerParameters(
                command=str(ENGINE_BIN), env=env, cwd=str(self.workspace))
            async with asyncio.timeout(120):
                async with stdio_client(parameters) as (reader, writer):
                    async with ClientSession(reader, writer) as client:
                        await client.initialize()
                        result = await client.call_tool(
                            "ctx_search", {"queries": [probe], "source": "cm-ticket2-acceptance"})
                        return "\n".join(getattr(item, "text", "") for item in result.content)

        found = asyncio.run(round_trip())
        (self.artifacts / "mcp-probe.txt").write_text(found, encoding="utf-8")
        self.check("mcp_independent_retrieval",
                   self.sentence_body in found,
                   f"public engine MCP ctx_search for never-queried phrase {probe!r} "
                   f"returned the pre-indexed sentence; tail: {found[-300:]!r}")

    # ── orchestration ───────────────────────────────────────────────────────
    def run(self) -> int:
        for received in (signal.SIGINT, signal.SIGTERM):
            signal.signal(received, lambda s, f, snum=received: self.interrupt.trip(snum))
        try:
            self.journal(f"evidence directory: {self.evid}")
            self.preflight()
            self.phase_seed_primary()
            self.phase_install_primary()
            self.phase_native_later_edits()
            self.phase_another_profile()
            self.phase_session_installed()
            self.phase_remove_primary()
            self.phase_session_removed()
            self.phase_recovery_and_repeat()
            self.phase_offline_and_missing()
            self.phase_reenable_offline()
            self.phase_session_reenabled()
            self.phase_mcp_probe()
        except V.Refused as exc:
            self.status, self.error = "fail", str(exc)
        except V.Interrupted as exc:
            self._interrupted = exc.signum
            self.status, self.error = "interrupted", str(exc)
        except BaseException as exc:
            import traceback
            (self.evid / "traceback.log").write_text(traceback.format_exc(), encoding="utf-8")
            self.status, self.error = "fail", f"{type(exc).__name__}: {exc}"
        finally:
            self._cleanup()
        failed = [name for name, c in self.checks.items() if not c["ok"]]
        if self.status == "pass" and failed:
            self.status, self.error = "fail", f"failed checks: {failed}"
        elif self.status == "pass":
            self.error = None
        self.write_results()
        if self._interrupted is not None:
            print(f"CM-TICKET2: INTERRUPTED evidence={self.evid}")
            return 143 if self._interrupted == signal.SIGTERM else 130
        print(f"CM-TICKET2: {self.status.upper()} evidence={self.evid}")
        return 0 if self.status == "pass" else 1

    def _cleanup(self) -> None:
        if self.provider is not None:
            try:
                self.provider.stop()
            except Exception:
                pass
        for name, home in self.profiles.items():
            try:
                V.sweep_owned(home, self.ledger, self.interrupt)
            except Exception as exc:
                self.journal(f"sweep({name}) error: {exc}")
        try:
            V.sweep_owned(self.evid, self.ledger, self.interrupt)
        except Exception as exc:
            self.journal(f"sweep(evidence) error: {exc}")
        try:
            strays = [h for h in V.owned_hermes_pids(EVIDENCE_ROOT, exclude={os.getpid()})]
        except Exception as exc:
            strays = [{"error": f"{type(exc).__name__}: {exc}"}]
        self.check("no_owned_survivors", not strays,
                   f"no live process carries HERMES_HOME under {EVIDENCE_ROOT} "
                   "after cleanup" + (f"; strays: {strays}" if strays else ""))
        if self.provider is not None:
            summary = self.provider.summarize()
            self.check("no_model_inference", summary["inference_attempts"] == 0,
                       f"loopback provider saw {summary['inference_attempts']} inference "
                       f"attempt(s), {summary.get('requests_total')} request(s) total")
        self.default_after = V.fingerprint_default_profile(self.default_root)
        (self.artifacts / "default-profile-after.json").write_text(
            json.dumps(self.default_after, indent=2), encoding="utf-8")
        if self.default_before is not None:
            self.check("default_profile_unchanged",
                       self.default_after == self.default_before,
                       f"default profile {self.default_root} fingerprint identical "
                       "before/after the whole lifecycle")

    def stop_gateway(self, home: Path, label: str) -> None:
        """Scoped reload: stop exactly the gateway daemon(s) serving *home* so
        the next session starts a fresh process reading the current config.
        Per-PID identity only: /proc environ HERMES_HOME == home plus start
        time re-verification before any signal; never a process group."""
        victims = [h for h in V.owned_hermes_pids(home, exclude={os.getpid()})]
        for hit in victims:
            env = V._proc_environ(hit["pid"]) or {}
            if env.get("HERMES_HOME") != str(home) or \
                    V._proc_starttime(hit["pid"]) != hit.get("starttime"):
                continue  # identity changed; never signal on stale proof
            try:
                os.kill(hit["pid"], signal.SIGTERM)
                self.ledger.signals.append({
                    "scope": "process", "identity": "owned",
                    "reason": f"gateway restart for {label}",
                    "pid": hit["pid"], "cmdline": hit.get("cmdline", "")[:200]})
            except (ProcessLookupError, PermissionError):
                pass
        deadline = time.monotonic() + 15
        while time.monotonic() < deadline:
            self.interrupt.check()
            remaining = V.owned_hermes_pids(home, exclude={os.getpid()})
            if not remaining:
                break
            time.sleep(0.2)
        for hit in V.owned_hermes_pids(home, exclude={os.getpid()}):
            env = V._proc_environ(hit["pid"]) or {}
            if env.get("HERMES_HOME") == str(home):
                try:
                    os.kill(hit["pid"], signal.SIGKILL)
                except (ProcessLookupError, PermissionError):
                    pass
        gone = not V.owned_hermes_pids(home, exclude={os.getpid()})
        self.check(f"gateway_restarted_{label}", gone,
                   f"gateway daemon(s) for {home} stopped before the next phase; "
                   "the following session starts a new process")

    def write_results(self) -> None:
        report = {
            "schema": REPORT_SCHEMA,
            "status": self.status,
            "error": self.error,
            "evidence_dir": str(self.evid),
            "repo": str(REPO),
            "git_head": subprocess.run(
                ["git", "-C", str(REPO), "rev-parse", "HEAD"],
                capture_output=True, text=True).stdout.strip(),
            "hermes_cli": str(HERMES),
            "engine_bin": str(ENGINE_BIN),
            "profiles": {k: str(v) for k, v in self.profiles.items()},
            "workspace": str(self.workspace),
            "sentence_body": self.sentence_body,
            "checks": self.checks,
            "processes": {
                "signals": self.ledger.signals,
                "identity_proofs": self.ledger.identity_proofs,
                "strays": self.ledger.strays,
            },
            "journal": self.journal_lines,
        }
        (self.evid / "acceptance-report.json").write_text(
            json.dumps(report, indent=2), encoding="utf-8")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--evidence-dir", type=Path, default=None)
    parser.add_argument("--command-timeout", type=float, default=300.0)
    parser.add_argument("--exit-timeout", type=float, default=30.0)
    args = parser.parse_args()
    return Acceptance(args).run()


if __name__ == "__main__":
    raise SystemExit(main())
