#!/usr/bin/env python3
"""Bisect why the gateway missed its startup deadline on profile A."""
import sys, time, json, shutil, uuid
from pathlib import Path

REPO = Path("/home/a1234/.cache/hermes-context-mode/worktrees/ticket-2")
sys.path.insert(0, str(REPO))
from context_mode_hermes import verify as V

VENV_PY = Path("/home/a1234/.cache/hermes-context-mode/hermes-agent/.venv/bin/python")
HERMES = VENV_PY.parent / "hermes"
ENGINE = Path("/home/a1234/.local/share/hermes-context-mode-validation/home/context-mode-runtime/node_modules/.bin/context-mode")
ROOT = Path("/home/a1234/.cache/hermes-context-mode/evidence/ticket-2/bisect")
ROOT.mkdir(parents=True, exist_ok=True)

interrupt = V._InterruptFlag()

def probe(name: str, extra_seed=None, native_edit=False, timeout=110.0):
    home = ROOT / name
    if home.exists():
        shutil.rmtree(home)
    home.mkdir(parents=True)
    os_chmod = lambda p: None
    import os as _os
    _os.chmod(home, 0o700)
    provider = V.LoopbackProvider(ROOT / f"{name}-provider", f"key-{name}")
    provider.start()
    try:
        V.write_owned_config(home, provider, ENGINE, f"key-{name}")
        if extra_seed:
            cfg = json.loads((home / "config.yaml").read_text())
            cfg.update(extra_seed)
            (home / "config.yaml").write_text(json.dumps(cfg, indent=2))
        env = V.child_environment(home)
        subprocess_env = env
        import subprocess as sp
        rec = sp.run([str(VENV_PY.parent / "context-mode-hermes"), "--home", str(home),
                      "--engine-bin", str(ENGINE)], env=env, capture_output=True, text=True)
        assert rec.returncode == 0, rec.stderr[-500:]
        if native_edit:
            edit = sp.run([str(VENV_PY), "-c",
                "from hermes_cli.config import load_config, save_config; "
                "cfg = load_config(); cfg['theme'] = 'light'; "
                "save_config(cfg, strip_defaults=False)"],
                env=env, capture_output=True, text=True)
            assert edit.returncode == 0, edit.stderr[-500:]
        ws = home / "workspace"; ws.mkdir(exist_ok=True)
        chat_env = dict(env); chat_env["TERM"] = "xterm-256color"
        driver = V.PtyChatDriver([str(HERMES), "--cli"], chat_env, ws,
                                 ROOT / f"{name}.log")
        started = time.monotonic()
        ok, elapsed = driver.wait_for("❯", timeout, interrupt)
        print(f"{name}: ready={ok} elapsed={elapsed:.1f}s", flush=True)
        if ok:
            driver.send("/exit")
            try:
                driver.proc.wait(timeout=20)
            except Exception:
                V.stop_child(driver.proc, V.ProcessLedger(), 20)
        else:
            V.stop_child(driver.proc, V.ProcessLedger(), 20)
        driver.close()
        return ok
    finally:
        provider.stop()

results = {}
results["p1-smoke-replica"] = probe("p1")
results["p2-with-extras"] = probe("p2", extra_seed={
    "theme": "dark", "operator_note": "x", "history": {"max_entries": 4096},
    "plugins": {"entries": {"example-plugin": {"description": "unrelated"}}},
})
results["p3-with-native-edit"] = probe("p3", native_edit=True)
results["p4-extras-no-plugin-entry"] = probe("p4", extra_seed={
    "theme": "dark", "operator_note": "x", "history": {"max_entries": 4096},
})
print("SUMMARY", json.dumps(results))
