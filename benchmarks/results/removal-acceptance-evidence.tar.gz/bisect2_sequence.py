#!/usr/bin/env python3
"""Bisect2: replicate the runner's exact phase order, probing chat readiness
on profile A after each phase."""
import json, shutil, subprocess, sys, time
from pathlib import Path

REPO = Path("/home/a1234/.cache/hermes-context-mode/worktrees/ticket-2")
sys.path.insert(0, str(REPO))
from context_mode_hermes import verify as V

VENV_PY = Path("/home/a1234/.cache/hermes-context-mode/hermes-agent/.venv/bin/python")
HERMES = VENV_PY.parent / "hermes"
CLI = VENV_PY.parent / "context-mode-hermes"
ENGINE = Path("/home/a1234/.local/share/hermes-context-mode-validation/home/context-mode-runtime/node_modules/.bin/context-mode")
ROOT = Path("/home/a1234/.cache/hermes-context-mode/evidence/ticket-2/bisect2")
if ROOT.exists():
    shutil.rmtree(ROOT)
ROOT.mkdir(parents=True)
interrupt = V._InterruptFlag()
A = ROOT / "profiles" / "A"; A.mkdir(parents=True); import os as _os; _os.chmod(A, 0o700)
B = ROOT / "profiles" / "B"; B.mkdir(parents=True); _os.chmod(B, 0o700)
WS = ROOT / "workspace"; WS.mkdir()
provider = V.LoopbackProvider(ROOT / "provider", "key-bisect2")
provider.start()

def cli(home, *extra):
    env = V.child_environment(home)
    return subprocess.run([str(CLI), "--home", str(home), *extra], env=env,
                          capture_output=True, text=True)

def probe(label, timeout=100.0):
    env = V.child_environment(A); env["TERM"] = "xterm-256color"
    driver = V.PtyChatDriver([str(HERMES), "--cli"], env, WS, ROOT / f"{label}.log")
    ok, elapsed = driver.wait_for("❯", timeout, interrupt)
    print(f"{label}: ready={ok} elapsed={elapsed:.1f}s", flush=True)
    if ok:
        driver.send("/exit")
        try: driver.proc.wait(timeout=20)
        except Exception: V.stop_child(driver.proc, V.ProcessLedger(), 20)
    else:
        V.stop_child(driver.proc, V.ProcessLedger(), 20)
    driver.close()
    return ok

try:
    V.write_owned_config(A, provider, ENGINE, "key-bisect2")
    cfg = json.loads((A / "config.yaml").read_text())
    cfg["theme"] = "dark"; cfg["operator_note"] = "ticket-2 owned profile marker"
    cfg["history"] = {"max_entries": 4096}
    cfg.setdefault("plugins", {}).setdefault("entries", {})["example-plugin"] = {
        "description": "unrelated operator plugin metadata (not enabled)"}
    (A / "config.yaml").write_text(json.dumps(cfg, indent=2))
    r = cli(A, "--engine-bin", str(ENGINE)); assert r.returncode == 0, r.stderr[-400:]
    probe("after-A-install")

    edit = subprocess.run([str(VENV_PY), "-c",
        "from hermes_cli.config import load_config, save_config; cfg = load_config(); "
        "cfg['theme'] = 'light'; cfg['operator_note'] = 'ticket-2 later native edit'; "
        "save_config(cfg, strip_defaults=False)"],
        env=V.child_environment(A), capture_output=True, text=True)
    assert edit.returncode == 0, edit.stderr[-400:]
    probe("after-native-edit")

    V.write_owned_config(B, provider, ENGINE, "key-bisect2-b")
    r = cli(B, "--engine-bin", str(ENGINE)); assert r.returncode == 0, r.stderr[-400:]
    probe("after-B-install")
finally:
    provider.stop()
print("DONE")
